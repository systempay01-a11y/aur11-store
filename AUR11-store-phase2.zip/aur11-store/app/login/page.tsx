import { signIn, signUp, resetPassword } from "@/app/auth/actions";

export default async function LoginPage({ searchParams }: { searchParams: Promise<{error?: string; message?: string}> }) {
  const params = await searchParams;
  return (
    <main className="auth-wrap">
      <section className="auth-card">
        <p className="eyebrow">AUR1:1 · AREA CLIENTI</p>
        <h1>Accedi o registrati</h1>
        <p>Gestisci il tuo account e, quando il negozio sarà attivato, i tuoi ordini.</p>
        {params.error && <p className="notice error">{params.error}</p>}
        {params.message && <p className="notice">{params.message}</p>}
        <form action={signIn} className="auth-form">
          <label>Email<input name="email" type="email" required autoComplete="email" /></label>
          <label>Password<input name="password" type="password" required autoComplete="current-password" /></label>
          <button type="submit">Accedi</button>
        </form>
        <div className="auth-divider">Nuovo cliente?</div>
        <form action={signUp} className="auth-form">
          <label>Email<input name="email" type="email" required autoComplete="email" /></label>
          <label>Password (almeno 10 caratteri)<input name="password" type="password" minLength={10} required autoComplete="new-password" /></label>
          <button type="submit" className="secondary-button">Crea account</button>
        </form>
        <div className="auth-divider">Password dimenticata?</div>
        <form action={resetPassword} className="auth-form">
          <label>Email<input name="email" type="email" required /></label>
          <button type="submit" className="text-button">Invia link di recupero</button>
        </form>
        <a className="back-link" href="/">← Torna al negozio</a>
      </section>
    </main>
  );
}
