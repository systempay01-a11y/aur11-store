const products = [
  { value: "10", name: "AUR1:1 Dieci", detail: "Singola banconota decorativa" },
  { value: "20", name: "AUR1:1 Venti", detail: "Singola banconota decorativa" },
  { value: "50", name: "AUR1:1 Cinquanta", detail: "Singola banconota decorativa" },
  { value: "150", name: "AUR1:1 Centocinquanta", detail: "Taglio speciale da gioco" },
  { value: "300", name: "AUR1:1 Trecento", detail: "Taglio speciale da gioco" },
  { value: "500", name: "AUR1:1 Cinquecento", detail: "Taglio speciale da gioco" },
  { value: "1500", name: "AUR1:1 Millecinquecento", detail: "Taglio speciale da gioco" },
];

export default function Home() {
  return <main>
    <header className="nav"><a className="brand" href="#">AUR<span>1:1</span></a><nav><a href="#prodotti">Prodotti</a><a href="#sicurezza">Info</a><a className="navButton" href="#prodotti">Scopri la collezione</a></nav></header>
    <section className="hero">
      <div className="float money m1">✦</div><div className="float money m2">◉</div><div className="float money m3">€</div>
      <p className="eyebrow">COLLEZIONE FUN MONEY</p>
      <h1>Un tocco d’oro.<br/><em>Un mondo di fantasia.</em></h1>
      <p className="lead">Banconote decorative originali per feste, giochi e scherzi. Creatività da collezionare, mai denaro reale.</p>
      <a className="goldButton" href="#prodotti">Esplora i prodotti <span>↗</span></a>
      <div className="seal">AUR1:1<br/><small>PLAY • PARTY • FUN</small></div>
    </section>
    <section className="section" id="prodotti">
      <div className="sectionHead"><div><p className="eyebrow">IL CATALOGO</p><h2>La collezione</h2></div><p>Sette tagli originali, un’unica identità.</p></div>
      <div className="grid">{products.map((p, i) => <article className="card" key={p.value}>
        <div className={`note note${i}`}><span className="noteBrand">AUR1:1</span><b>{p.value}</b><span className="noteWords">FUN • PLAY • NOT MONEY</span><small>FAC-SIMILE · NON VALIDO</small></div>
        <div className="productInfo"><div><h3>{p.name}</h3><p>{p.detail}</p></div><span className="tag">NOVITÀ</span></div>
        <p className="price">Prezzo da definire</p>
        <button className="outlineButton" disabled title="Acquisti attivabili dopo configurazione di catalogo, account e pagamenti">Disponibile prossimamente</button>
      </article>)}</div>
    </section>
    <section className="trust" id="sicurezza"><div><p className="eyebrow">CHIARO. ORIGINALE. RESPONSABILE.</p><h2>Fatti per divertirsi,<br/><em>non per pagare.</em></h2></div><p>I prodotti AUR1:1 sono oggetti di fantasia per intrattenimento. Non sono valuta, non hanno corso legale e non sono utilizzabili per acquisti o pagamenti. Il design finale dovrà restare chiaramente distinto dall’euro autentico.</p></section>
    <footer><a className="brand" href="#">AUR<span>1:1</span></a><p>© {new Date().getFullYear()} AUR1:1 · Fun Money</p><small>Prodotti decorativi non spendibili. Nessun valore monetario.</small></footer>
  </main>;
}