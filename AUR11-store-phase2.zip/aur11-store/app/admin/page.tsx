import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createProduct, setProductActive, deleteProduct } from "./actions";

export default async function AdminPage({ searchParams }: { searchParams: Promise<{error?: string; message?: string}> }) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user || user.app_metadata?.role !== "admin") redirect("/login");
  const { data: products, error } = await supabase.from("products").select("*").order("created_at", { ascending: false });
  const params = await searchParams;
  return (
    <main className="admin-wrap">
      <header className="admin-header">
        <div><p className="eyebrow">AUR1:1 · BACK OFFICE</p><h1>Pannello amministratore</h1><p>Connesso come {user.email}</p></div>
        <a className="back-link" href="/">← Negozio</a>
      </header>
      {params.error && <p className="notice error">{params.error}</p>}
      {params.message && <p className="notice">{params.message}</p>}
      {error && <p className="notice error">Database non configurato o tabella products non disponibile.</p>}
      <section className="admin-panel">
        <h2>Aggiungi prodotto</h2>
        <form action={createProduct} className="product-form">
          <label>Nome prodotto<input name="title" required placeholder="AUR1:1 – 10" /></label>
          <label>Taglio nominale<input name="denomination" type="number" step="1" required /></label>
          <label>Prezzo in euro<input name="price" type="number" min="0" step="0.01" required /></label>
          <label>Quantità a magazzino<input name="stock" type="number" min="0" step="1" required /></label>
          <label className="wide">Descrizione<input name="description" required placeholder="Oggetto decorativo di fantasia, fac-simile non spendibile." /></label>
          <button type="submit">Crea prodotto</button>
        </form>
      </section>
      <section className="admin-panel">
        <h2>Catalogo ({products?.length || 0})</h2>
        {!products?.length ? <p>Nessun prodotto salvato nel database.</p> : (
          <div className="admin-products">
            {products.map((p: any) => <article className="admin-product" key={p.id}>
              <div><strong>{p.title}</strong><p>Taglio {p.denomination} · €{(p.price_cents / 100).toFixed(2)} · Stock: {p.stock}</p><small>{p.active ? "Visibile" : "Nascosto"}</small></div>
              <div className="admin-actions">
                <form action={setProductActive}><input type="hidden" name="id" value={p.id}/><input type="hidden" name="active" value={String(!p.active)}/><button className="secondary-button">{p.active ? "Nascondi" : "Pubblica"}</button></form>
                <form action={deleteProduct}><input type="hidden" name="id" value={p.id}/><button className="danger-button">Elimina</button></form>
              </div>
            </article>)}
          </div>
        )}
      </section>
      <p className="admin-footnote">L’accesso admin dipende dal ruolo server-side in app_metadata. Non assegnare ruoli dal browser.</p>
    </main>
  );
}
