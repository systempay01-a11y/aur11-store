"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

async function requireAdmin() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user || user.app_metadata?.role !== "admin") redirect("/login");
  return supabase;
}

export async function createProduct(formData: FormData) {
  const supabase = await requireAdmin();
  const title = String(formData.get("title") || "").trim();
  const denomination = Number(formData.get("denomination"));
  const price = Number(formData.get("price"));
  const description = String(formData.get("description") || "").trim();
  const stock = Number(formData.get("stock"));
  if (!title || !description || !Number.isFinite(price) || price < 0 ||
      !Number.isInteger(stock) || stock < 0 || !Number.isFinite(denomination)) {
    redirect("/admin?error=Dati%20prodotto%20non%20validi");
  }
  const { error } = await supabase.from("products").insert({
    title, denomination, price_cents: Math.round(price * 100), description, stock, active: true
  });
  if (error) redirect("/admin?error=Salvataggio%20non%20riuscito");
  revalidatePath("/admin");
  revalidatePath("/");
  redirect("/admin?message=Prodotto%20creato");
}

export async function setProductActive(formData: FormData) {
  const supabase = await requireAdmin();
  const id = String(formData.get("id") || "");
  const active = String(formData.get("active")) === "true";
  await supabase.from("products").update({ active }).eq("id", id);
  revalidatePath("/admin");
  revalidatePath("/");
}

export async function deleteProduct(formData: FormData) {
  const supabase = await requireAdmin();
  const id = String(formData.get("id") || "");
  await supabase.from("products").delete().eq("id", id);
  revalidatePath("/admin");
  revalidatePath("/");
}
