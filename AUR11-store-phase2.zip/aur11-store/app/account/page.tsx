import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { signOut } from "@/app/auth/actions";

export default async function AccountPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  return (
    <main className="auth-wrap">
      <section className="auth-card">
        <p className="eyebrow">AUR1:1 · ACCOUNT</p>
        <h1>Benvenuto</h1>
        <p>Accesso effettuato come <strong>{user.email}</strong>.</p>
        <p>Lo storico ordini sarà disponibile quando verrà attivato il checkout.</p>
        <form action={signOut}><button type="submit" className="secondary-button">Esci</button></form>
        <a className="back-link" href="/">Torna al negozio</a>
      </section>
    </main>
  );
}
