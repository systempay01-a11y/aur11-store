import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AUR1:1 — Fun Money",
  description: "Banconote decorative originali per giochi, feste e scherzi.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="it"><body>{children}</body></html>;
}