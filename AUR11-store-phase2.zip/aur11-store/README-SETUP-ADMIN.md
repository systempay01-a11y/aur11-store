# AUR1:1 — Fase 2: account e primo back office

Questa versione aggiunge una base tecnica per autenticazione Supabase e gestione prodotti.
**Non è ancora un negozio pronto a ricevere ordini o pagamenti.**

## 1. Crea il progetto Supabase
1. Crea un progetto su Supabase.
2. In SQL Editor, esegui tutto il contenuto di `supabase/schema.sql`.
3. In Authentication > URL Configuration, imposta Site URL e Redirect URLs per il tuo dominio (e `http://localhost:3000/**` in sviluppo).
4. In Project Settings > API, copia Project URL e anon/public key.

## 2. Configura le variabili
Copia `.env.example` in `.env.local` e inserisci:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `NEXT_PUBLIC_SITE_URL` (es. `http://localhost:3000` in locale)

Non condividere mai password, service-role key o segreti di pagamento.

## 3. Avvia il progetto
```bash
npm install
npm run dev
```
Apri `http://localhost:3000/login`.

## 4. Crea l'account amministratore
1. Registrati dalla pagina `/login` usando l'indirizzo amministratore previsto: `systempay01@gmail.com`.
2. Conferma l'indirizzo email dal messaggio ricevuto.
3. In Supabase Dashboard > Authentication > Users, apri l'utente verificato.
4. Modifica **app_metadata** impostandolo a:
```json
{"role":"admin"}
```
5. Esci e accedi di nuovo, poi apri `/admin`.

Il ruolo è letto da `app_metadata` lato server e verificato anche dalle policy RLS del database. Non mettere mai il ruolo in `user_metadata`.

## Cosa funziona in questa fase
- registrazione e accesso email/password;
- conferma email tramite callback;
- richiesta di recupero password;
- pagina account protetta;
- back office protetto per amministratore;
- creazione, pubblicazione/nascondimento ed eliminazione prodotti.

## Cosa manca ancora
- modifica completa dei prodotti e caricamento immagini su Storage;
- carrello persistente, checkout, ordini, email e resi;
- gestione sicura di pagamenti crypto e webhook;
- deploy pubblico, dominio, backup e monitoraggio;
- testi legali, privacy/cookie e verifica normativa.

## Sicurezza e prodotti
Le banconote devono restare oggetti grafici di fantasia, chiaramente marcati `FAC-SIMILE` e `NON VALIDO`, senza imitare le banconote euro autentiche. Prima della vendita, verifica la conformità legale applicabile. Non attivare pagamenti prima di aver scelto e verificato un provider idoneo.
