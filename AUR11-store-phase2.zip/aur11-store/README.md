# AUR1:1 — starter e-commerce

Questo archivio contiene una **base grafica navigabile**, non un negozio già operativo. Il catalogo mostra sette concept originali di banconote decorative: 10, 20, 50, 150, 300, 500 e 1500.

## Avvio locale
1. Installa Node.js 20 o superiore.
2. Nella cartella del progetto esegui `npm install`.
3. Esegui `npm run dev`.
4. Apri `http://localhost:3000`.

## Per trasformarlo in un vero negozio
Sono ancora da configurare e collaudare:
- progetto Supabase, autenticazione email, database, storage immagini e policy RLS;
- ruolo amministratore assegnato lato server all'account autorizzato `systempay01@gmail.com` (mai fidarsi di un ruolo salvato dal browser);
- gestione prodotti, prezzi, inventario, carrello, ordini, email e resi;
- un provider di pagamento crypto idoneo, con webhook firmati verificati lato server, gestione conferme e rimborsi;
- hosting, dominio, HTTPS, backup, log, privacy/cookie policy, termini di vendita e assistenza.

Il file `.env.example` mostra soltanto le variabili pubbliche Supabase da impostare. Non inserire chiavi segrete nel browser o nel repository.

## Importante sui prodotti
I concept grafici in questa demo sono intenzionalmente astratti e non riproducono le banconote euro. Prima della vendita, ogni prodotto fisico deve essere verificato rispetto alle regole applicabili sulle riproduzioni di valuta e deve risultare inequivocabilmente un oggetto di fantasia, non spendibile e non confondibile con valuta autentica.

## Stato
- [x] Identità verde smeraldo e oro, animazione lenta, homepage responsive.
- [x] Catalogo iniziale con sette tagli nominali.
- [ ] Account clienti e amministratore.
- [ ] CRUD prodotti e immagini persistenti.
- [ ] Carrello, ordini, pagamenti e notifiche.
- [ ] Deploy pubblico.

Non sono inclusi account cloud, credenziali, dominio registrato o pagamenti attivi.


## Fase 2
Consulta `README-SETUP-ADMIN.md` per configurare Supabase, registrazione clienti e pannello amministratore `/admin`. Questa fase non abilita ancora checkout o pagamenti.
